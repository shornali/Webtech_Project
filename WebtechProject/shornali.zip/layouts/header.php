<!DOCTYPE html>
<html lang="en">
<head>
    <title></title>
</head>
<body>
    <table>
        <tr>
            <td> <img src="../../assets/A_star_icon.png" width="50px" height="50px"> </td>
            <td> <h2>Restaurant Management System</h2> </td>
        </tr>
        <tr>
            <td align="center"> <a href="..\view\login.php">Login </a> </td>
            <td align="center"> <a href="..\view\registration.php">Registration </a> </td>
        </tr>
    </table>
    <br><br>
</body>
</html>